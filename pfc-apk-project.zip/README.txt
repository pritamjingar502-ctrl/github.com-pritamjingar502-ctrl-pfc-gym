Upload these files to a new GitHub repo. Actions tab > Build APK > download PFC-Gym-APK.
